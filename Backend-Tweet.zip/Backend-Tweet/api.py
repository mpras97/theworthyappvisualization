"""Listed all the twitter api."""

tweetags_api = {
    "app_only_auth_token": "https://api.twitter.com/oauth2/token",
}

