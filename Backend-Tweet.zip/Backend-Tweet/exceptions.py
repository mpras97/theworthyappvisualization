#! /usr/bin/env python


""" Custom exception handling."""


class AccessTokenError(Exception):

    """If api key or access token is None."""

    pass

